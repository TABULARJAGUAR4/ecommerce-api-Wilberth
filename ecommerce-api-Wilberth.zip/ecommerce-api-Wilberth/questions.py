import mysql.connector

# Conéctate a tu base de datos
connection = mysql.connector.connect(
    host="mysql-wilberth.alwaysdata.net",
    user="wilberth_iry71",
    password="octubre20",
    database="wilberth_iry71"
)

cursor = connection.cursor()

# 1. Ventas Totales
cursor.execute("SELECT SUM(p.precio * v.cantidad) "
               "FROM ventas v "
               "JOIN productos p ON v.id_producto = p.id_producto")
total_ingresos = cursor.fetchone()[0]

# 2. Producto más vendido
cursor.execute("SELECT p.nombre_producto, MAX(v.cantidad) AS total_vendido "
               "FROM productos p "
               "JOIN ventas v ON p.id_producto = v.id_producto "
               "GROUP BY p.id_producto "
               "ORDER BY total_vendido DESC LIMIT 1")
producto_mas_vendido = cursor.fetchone()

# 3. Categoría más vendida
cursor.execute("SELECT c.nombre_categoria, SUM(v.cantidad) AS total_vendido "
               "FROM categorias c "
               "JOIN productos p ON c.id_categoria = p.id_categoria "
               "JOIN ventas v ON p.id_producto = v.id_producto "
               "GROUP BY c.id_categoria "
               "ORDER BY total_vendido DESC LIMIT 1")
categoria_mas_vendida = cursor.fetchone()
    
cursor.execute("SELECT SUM(stock) FROM productos")
total_productos_en_stock = cursor.fetchone()[0]

# 4. Usuarios y Comportamiento de Compra
cursor.execute("SELECT u.nombre_usuario, SUM(p.precio * v.cantidad) AS total_gastado "
               "FROM usuarios u "
               "JOIN ventas v ON u.id_usuario = v.id_usuario "
               "JOIN productos p ON v.id_producto = p.id_producto "
               "GROUP BY u.id_usuario "
               "ORDER BY total_gastado DESC LIMIT 1")
usuario_mas_gastador = cursor.fetchone()

cursor.execute("SELECT AVG(cantidad) FROM (SELECT id_usuario, SUM(cantidad) as cantidad FROM ventas GROUP BY id_usuario) as subquery")
resultados_promedio_gasto_usuario = cursor.fetchall()

# Verificar si hay resultados antes de intentar acceder
if resultados_promedio_gasto_usuario:
    promedio_gasto_usuario = resultados_promedio_gasto_usuario[0][0]
else:
    promedio_gasto_usuario = 0  # o cualquier valor por defecto que desees

# Calcula y muestra el promedio de productos comprados por usuario
cursor.execute("SELECT COUNT(*) as total_productos_comprados FROM ventas")
total_productos_comprados = cursor.fetchone()[0]

cursor.execute("SELECT COUNT(DISTINCT id_usuario) as total_usuarios FROM ventas")
total_usuarios = cursor.fetchone()[0]

promedio_productos_comprados_por_usuario = total_productos_comprados / total_usuarios


# 5. Inventario
cursor.execute("SELECT SUM(stock) FROM productos")
productos_en_stock = cursor.fetchone()[0]

cursor.execute("SELECT nombre_producto, MIN(stock) FROM productos")
producto_con_menos_stock = cursor.fetchone()

cursor.execute("SELECT COUNT(*) FROM productos WHERE stock < 10")
productos_con_stock_bajo = cursor.fetchone()[0]

# 6. Productos
cursor.execute("SELECT nombre_producto, precio FROM productos ORDER BY precio DESC LIMIT 1")
producto_mas_caro = cursor.fetchone()

cursor.execute("SELECT nombre_producto, precio FROM productos ORDER BY precio ASC LIMIT 1")
producto_mas_barato = cursor.fetchone()

cursor.execute("SELECT AVG(precio) FROM productos")
promedio_precios_productos = cursor.fetchone()[0]

# Imprime las respuestas
print("1. Ventas Totales:")
print(f"- ¿Cuánto es el ingreso total de todas las ventas?\n  - Respuesta: {total_ingresos}")
print(f"- ¿Cuál es el producto más vendido?\n  - Respuesta: {producto_mas_vendido[0]} con {producto_mas_vendido[1]} unidades vendidas")
print(f"- ¿Cuál es la categoría más vendida?\n  - Respuesta: {categoria_mas_vendida[0]} con {categoria_mas_vendida[1]} unidades vendidas")

print("\n2. Usuarios y Comportamiento de Compra:")
print(f"- ¿Cuál es el usuario que más ha gastado?\n  - Respuesta: {usuario_mas_gastador[0]} con un gasto de {usuario_mas_gastador[1]}")
print(f"- ¿Cuál es el promedio de gasto por usuario?\n  - Respuesta: {promedio_gasto_usuario}")
print(f"- ¿Cuántos productos compra un usuario en promedio?\n  - Respuesta: {promedio_productos_comprados_por_usuario}")

print("\n3. Inventario:")
print(f"- ¿Cuántos productos están actualmente en stock?\n  - Respuesta: {total_productos_en_stock}")
print(f"- ¿Cuál es el producto con menos stock?\n  - Respuesta: {producto_con_menos_stock[0]} con {producto_con_menos_stock[1]} unidades en stock")
print(f"- ¿Cuántos productos necesitan ser reabastecidos (stock bajo)?\n  - Respuesta: {productos_con_stock_bajo}")

print("\n4. Productos:")
print(f"- ¿Cuál es el producto más caro?\n  - Respuesta: {producto_mas_caro[0]} con un precio de {producto_mas_caro[1]}")
print(f"- ¿Cuál es el producto más barato?\n  - Respuesta: {producto_mas_barato[0]} con un precio de {producto_mas_barato[1]}")
print(f"- ¿Cuál es el promedio de precios de los productos?\n  - Respuesta: {promedio_precios_productos}")

# Cierra la conexión
connection.close()