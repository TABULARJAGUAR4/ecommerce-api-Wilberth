const  mysql = require('mysql2/promise');

const pool = mysql.createPool({
    host:"mysql-wilberth.alwaysdata.net",
    user:"wilberth_iry71",
    password:"octubre20",
    database:"wilberth_iry71",
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
});

module.exports = pool;