/ / insertar categorias datos en la tabla id_categoria,
nombre_categoria

INSERT INTO
    categorias (nombre_categoria)
VALUES
    ('Electronicos'),
    ('Ropa'),
    ('Hogar'),
    ('Juguetes'),
    ('Deportes');